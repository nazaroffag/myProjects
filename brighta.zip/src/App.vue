<template>
  <div id="wrapper">
    <div id="top-panel">
      <div id="title-wrapper">
        <ojowo-logo />
        <!-- <span>Beta</span> -->
      </div>
      <top-module />
    </div>
    <div id="content">
      <aside>
        <side-panel />
      </aside>
      <main>
        <summary-analitics />
      </main>
    </div>
  </div>
</template>

<script>
import SidePanel from "./components/SidePanel/SidePanel.vue";
import TopModule from "./components/TopModule/TopModule.vue";
import OjowoLogo from "./assets/ojowoLogo.vue";
import SummaryAnalitics from "./components/SummaryAnalitics/SummaryAnalitics.vue";

export default {
  name: "App",
  components: {
    TopModule,
    SidePanel,
    OjowoLogo,
    SummaryAnalitics,
  },
  data() {
    return {};
  },
  methods: {},
  mounted() {},
};
</script>

<style src="./App.css">
</style>
