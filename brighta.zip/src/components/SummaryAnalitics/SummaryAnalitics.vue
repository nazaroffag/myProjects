<template>
  <div id="summary">
    <div class="summary-card" v-for="(card, idx) in cards" :key="idx">
      <div class="summary-card-header">
        <div class="summary-card-header-title">{{ card.card }}</div>
        <div class="summary-card-header-check">
          <input
            type="checkbox"
            name="toggle"
            :id="`${idx}checkbox`"
            :ref="`${card.first + idx + 'checkbox'}`"
            class="toggle-button"
            @change="checkHandler(card.first + idx, card)"
          />
          <span class="summary-card-header-check_span left">Все время</span>

          <span class="summary-card-header-check_span">Месяц</span>
        </div>
      </div>
      <div class="summary-card-graph">
        <div class="summary-card-inner-circle">
          <div class="summary-card-circle-fill"></div>
        </div>
        <div class="summary-card-outer-circle"></div>
        <div class="summary-card-numbers">
          <h2
            class="summary-card-numbers_h2"
            :ref="`${card.first + idx + 'h2'}`"
          >
            {{ card.firstP }}
          </h2>
          <div
            class="summary-card-numbers_span"
            :ref="`${card.first + idx + 'span'}`"
          >
            {{ card.firstSpan }}
          </div>
          <div class="arrow-wrapper">
            <img
              v-if="setArrow(card.first + idx + 'p', card)"
              :ref="`${card.first + idx + 'arr'}`"
              class="summary-card-numbers_arrow"
              :src="getImgUrl('upArrow')"
              alt="upArrow"
            />
            <img
              v-if="!setArrow(card.first + idx + 'p', card)"
              :ref="`${card.first + idx + 'arr'}`"
              class="summary-card-numbers_arrow"
              :src="getImgUrl('downArrow')"
              alt="upArrow"
            />
            <div class="summary-card-element-popup arrow-popup">
              <div class="comment_bubble">
                <p class="comment_text" :ref="`${card.first + idx + 'p'}`">
                  {{ card.arrowFirst }}
                </p>
                <span class="comment_text">%</span>
              </div>
            </div>
          </div>
        </div>
        <!-- idx -->
        <div
          class="summary-card-element first active_element"
          :ref="`${card.first + idx}`"
        >
          <div
            class="summary-card-element-click"
            @click.stop="checkElement($event, card.first + idx, card)"
          >
            <div class="summary-card-element-popup">
              <div class="comment_bubble">
                <p class="comment_text">{{ card.firstFooter }}</p>
              </div>
            </div>
          </div>

          <img
            class="summary-card-element_img"
            :src="`${getImgUrl(card.first)}`"
            :alt="`${card.first}`"
          />
          <p class="summary-card-element_p">
            {{ card.firstP }}
          </p>
          <span class="summary-card-element_span">{{ card.firstSpan }}</span>
        </div>
        <!-- +1 -->
        <div
          class="summary-card-element"
          :class="{
            hidden: !card.second,
            second_middle: !card.third,
            second: card.third,
          }"
          :ref="`${card.first + idx + 1}`"
        >
          <div
            class="summary-card-element-click"
            @click.stop="checkElement($event, card.first + idx, card)"
          >
            <div class="summary-card-element-popup">
              <div class="comment_bubble">
                <p class="comment_text">{{ card.secondFooter }}</p>
              </div>
            </div>
          </div>

          <img
            class="summary-card-element_img"
            :src="`${getImgUrl(card.second)}`"
            :alt="`${card.second}`"
          />
          <p class="summary-card-element_p">{{ card.secondP }}</p>
          <span class="summary-card-element_span">{{ card.secondSpan }}</span>
        </div>
        <!-- +2 -->
        <div
          class="summary-card-element third"
          :class="{ hidden: !card.third }"
          :ref="`${card.first + idx + 2}`"
        >
          <div
            class="summary-card-element-click"
            @click.stop="checkElement($event, card.first + idx, card)"
          >
            <div class="summary-card-element-popup">
              <div class="comment_bubble">
                <p class="comment_text">{{ card.thirdFooter }}</p>
              </div>
            </div>
          </div>

          <img
            class="summary-card-element_img"
            :src="`${getImgUrl(card.third)}`"
            :alt="`${card.third}`"
          />
          <p class="summary-card-element_p">{{ card.thirdP }}</p>
          <span class="summary-card-element_span">{{ card.thirdSpan }}</span>
        </div>
        <!-- +3 -->
        <div
          class="summary-card-element fourth"
          :class="{ hidden: !card.fourth }"
          :ref="`${card.first + idx + 3}`"
        >
          <div
            class="summary-card-element-click"
            @click.stop="checkElement($event, card.first + idx, card)"
          >
            <div class="summary-card-element-popup">
              <div class="comment_bubble">
                <p class="comment_text">{{ card.fourthFooter }}</p>
              </div>
            </div>
          </div>

          <img
            class="summary-card-element_img"
            :src="`${getImgUrl(card.fourth)}`"
            :alt="`${card.fourth}`"
          />
          <p class="summary-card-element_p">{{ card.fourthP }}</p>
          <span class="summary-card-element_span">{{ card.fourthSpan }}</span>
        </div>
      </div>

      <div class="summary-card-footer" :ref="`${card.first + idx + 'footer'}`">
        {{ card.firstFooter }}
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      cards: [
        {
          card: "Продажи",
          arrow: "upArrow",
          first: "salesSumm24",
          firstP: "376",
          firstSpan: "USD",
          arrowFirst: 218.48,
          firstFooter: "Сумма продаж",
          second: "averageCheck24",
          secondP: 8,
          secondSpan: "USD",
          arrowSecond: 18.48,
          secondFooter: "Средний чек",
          third: "amountOfTransactions24",
          thirdP: 46,
          thirdSpan: null,
          arrowThird: 21.48,
          thirdFooter: "Количество транзакций",
          fourth: null,
          fourtP: null,
          fourtSpan: null,
          fourthFooter: null,
        },
        {
          card: "Продукты",
          arrow: "upArrow",
          first: "amountOfActiveUsers24",
          firstP: "1349",
          firstSpan: null,
          arrowFirst: -8.48,
          firstFooter: "Активных учеников",
          second: "amountOfProducts24",
          secondP: 84,
          secondSpan: null,
          arrowSecond: 218.48,
          secondFooter: "Количество продуктов",
          third: null,
          thirdP: null,
          thirdSpan: null,
          fourth: null,
          fourtP: null,
          fourtSpan: null,
        },
        {
          card: "Маркетинг",
          arrow: "upArrow",
          first: "emailMarketing24",
          firstP: "255/",
          firstSpan: 500,
          arrowFirst: -56.89,
          firstFooter: "Маркетинг емейлов",
          second: "serviceEmail24",
          secondP: "20/",
          secondSpan: 600,
          arrowSecond: 2.3,
          secondFooter: "Сервис емейлов",
          third: "companiesEmail24",
          thirdP: 12,
          thirdSpan: null,
          arrowThird: -218.48,
          thirdFooter: "Емейлы компаний",
          fourth: null,
          fourtP: null,
          fourtSpan: null,
        },
        {
          card: "Ресурсы",
          arrow: "downArrow",
          first: "totalUsed24",
          firstP: "1345",
          firstSpan: "GB",
          arrowFirst: 218.48,
          firstFooter: "Использовано траффика",
          second: "forMediaFiles24",
          secondP: "0,17",
          secondSpan: "GB",
          arrowSecond: -218.48,
          secondFooter: "Под медиа файлы",
          third: null,
          thirdP: null,
          thirdSpan: null,
          fourth: null,
          fourtP: null,
          fourtSpan: null,
        },
        {
          card: "Контакты",
          arrow: "upArrow",
          first: "contactsMarketing24",
          firstP: 7200,
          firstSpan: null,
          arrowFirst: 218.48,
          firstFooter: "Маркетинг контактов",
          second: "amountOfActiveUsers24",
          secondP: 1349,
          secondSpan: null,
          arrowSecond: -218.48,
          secondFooter: "Число активных пользователей",
          third: "amountOfContacts24",
          thirdP: 5831,
          thirdSpan: null,
          arrowThird: 218.48,
          thirdFooter: "Число контактов",
          fourth: "newActiveUsers24",
          fourthP: 531,
          fourthSpan: null,
          arrowFourth: -21.48,
          fourthFooter: "Число новых активных пользователей",
        },
      ],
    };
  },
  methods: {
    getImgUrl(pic) {
      if (pic) {
        return require("./assets/" + pic + ".svg");
      }
    },
    setArrow(idx, card) {
      if (this.$refs[idx]) {
        let str = Number(this.$refs[idx].innerHTML);
        if (str > 0) {
          return true;
        } else {
          return false;
        }
      } else {
        if (card.arrowFirst > 0) {
          return true;
        } else {
          return false;
        }
      }
    },
    resetSummaryCard(idx, card) {
      this.$refs[idx].className =
        "summary-card-element" + " first" + " active_element";
      this.$refs[idx + "1"].className = "summary-card-element" + " second";
      if (card.third) {
        this.$refs[idx + "2"].className = "summary-card-element" + " third";
      }
      if (!this.$refs[idx + "checkbox"].checked) {
        if (card.fourth) {
          this.$refs[idx + "3"].className = "summary-card-element" + " fourth";
        }
      }
      this.$refs[idx + "h2"].innerHTML = card.firstP;
      this.$refs[idx + "span"].innerHTML = card.firstSpan;
      this.$refs[idx + "footer"].innerHTML = card.firstFooter;
      this.$refs[idx + "p"].innerHTML = card.arrowFirst;
    },
    checkElement(e, idx, card) {
      if (!e.target.offsetParent.className.includes("first")) {
        if (e.target.offsetParent.className.includes("second_middle")) {
          this.$refs[idx].className.includes("first")
            ? (this.$refs[idx].className =
                "summary-card-element" + " second_middle")
            : (this.$refs[idx].className =
                "summary-card-element" + " first" + " active_element");
          this.$refs[idx + 1].className.includes("second_middle")
            ? (this.$refs[idx + 1].className =
                "summary-card-element" + " first" + " active_element")
            : (this.$refs[idx + 1].className =
                "summary-card-element" + " second_middle");
          this.$refs[idx + "footer"].innerHTML === card.firstFooter
            ? (this.$refs[idx + "footer"].innerHTML = card.secondFooter)
            : (this.$refs[idx + "footer"].innerHTML = card.firstFooter);
          this.$refs[idx + "h2"].innerHTML === card.firstP
            ? (this.$refs[idx + "h2"].innerHTML = card.secondP)
            : (this.$refs[idx + "h2"].innerHTML = card.firstP);
          this.$refs[idx + "span"].innerHTML === card.firstSpan
            ? (this.$refs[idx + "span"].innerHTML = card.secondSpan)
            : (this.$refs[idx + "span"].innerHTML = card.firstSpan);
          this.$refs[idx + "p"].innerHTML == card.arrowFirst
            ? (this.$refs[idx + "p"].innerHTML = card.arrowSecond)
            : (this.$refs[idx + "p"].innerHTML = card.arrowFirst);
          this.setArrow(idx + "p", card)
            ? (this.$refs[idx + "arr"].src = this.getImgUrl("upArrow"))
            : (this.$refs[idx + "arr"].src = this.getImgUrl("downArrow"));
        }
        if (e.target.offsetParent.className.includes("second")) {
          if (
            this.$refs[idx].className.includes("third") ||
            this.$refs[idx].className.includes("fourth") ||
            this.$refs[idx + 3].className.includes("first")
          ) {
            this.resetSummaryCard(idx, card);
          }
          this.$refs[idx].className.includes("first")
            ? (this.$refs[idx].className = "summary-card-element" + " second")
            : (this.$refs[idx].className =
                "summary-card-element" + " first" + " active_element");
          this.$refs[idx + 1].className.includes("first")
            ? (this.$refs[idx + 1].className =
                "summary-card-element" + " second")
            : (this.$refs[idx + 1].className =
                "summary-card-element" + " first" + " active_element");
          this.$refs[idx + "footer"].innerHTML === card.firstFooter
            ? (this.$refs[idx + "footer"].innerHTML = card.secondFooter)
            : (this.$refs[idx + "footer"].innerHTML = card.firstFooter);
          this.$refs[idx + "h2"].innerHTML == card.firstP
            ? (this.$refs[idx + "h2"].innerHTML = card.secondP)
            : (this.$refs[idx + "h2"].innerHTML = card.firstP);
          this.$refs[idx + "span"].innerHTML == card.firstSpan
            ? (this.$refs[idx + "span"].innerHTML = card.secondSpan)
            : (this.$refs[idx + "span"].innerHTML = card.firstSpan);
          this.$refs[idx + "p"].innerHTML == card.arrowFirst
            ? (this.$refs[idx + "p"].innerHTML = card.arrowSecond)
            : (this.$refs[idx + "p"].innerHTML = card.arrowFirst);
          this.setArrow(idx + "p", card)
            ? (this.$refs[idx + "arr"].src = this.getImgUrl("upArrow"))
            : (this.$refs[idx + "arr"].src = this.getImgUrl("downArrow"));
        }
        if (e.target.offsetParent.className.includes("third")) {
          if (
            this.$refs[idx].className.includes("second") ||
            this.$refs[idx].className.includes("fourth") ||
            this.$refs[idx + 3].className.includes("first")
          ) {
            this.resetSummaryCard(idx, card);
          }
          this.$refs[idx + 2].className.includes("first")
            ? (this.$refs[idx + 2].className =
                "summary-card-element" + " third")
            : (this.$refs[idx + 2].className =
                "summary-card-element" + " first" + " active_element");
          this.$refs[idx].className.includes("third")
            ? (this.$refs[idx].className =
                "summary-card-element" + " first" + " active_element")
            : (this.$refs[idx].className = "summary-card-element" + " third");
          this.$refs[idx + "footer"].innerHTML === card.firstFooter
            ? (this.$refs[idx + "footer"].innerHTML = card.thirdFooter)
            : (this.$refs[idx + "footer"].innerHTML = card.firstFooter);
          this.$refs[idx + "h2"].innerHTML == card.firstP
            ? (this.$refs[idx + "h2"].innerHTML = card.thirdP)
            : (this.$refs[idx + "h2"].innerHTML = card.firstP);
          this.$refs[idx + "span"].innerHTML == card.firstSpan
            ? (this.$refs[idx + "span"].innerHTML = card.thirdSpan)
            : (this.$refs[idx + "span"].innerHTML = card.firstSpan);
          this.$refs[idx + 1].className = "summary-card-element" + " second";
          this.$refs[idx + "p"].innerHTML == card.arrowFirst
            ? (this.$refs[idx + "p"].innerHTML = card.arrowThird)
            : (this.$refs[idx + "p"].innerHTML = card.arrowFirst);
          this.setArrow(idx + "p", card)
            ? (this.$refs[idx + "arr"].src = this.getImgUrl("upArrow"))
            : (this.$refs[idx + "arr"].src = this.getImgUrl("downArrow"));
        }
        if (e.target.offsetParent.className.includes("fourth")) {
          if (
            this.$refs[idx].className.includes("third") ||
            this.$refs[idx].className.includes("second")
          ) {
            this.resetSummaryCard(idx, card);
          }
          this.$refs[idx + 3].className.includes("first")
            ? (this.$refs[idx + 3].className =
                "summary-card-element" + " fourth")
            : (this.$refs[idx + 3].className =
                "summary-card-element" + " first" + " active_element");
          this.$refs[idx].className.includes("fourth")
            ? (this.$refs[idx].className =
                "summary-card-element" + " first" + " active_element")
            : (this.$refs[idx].className = "summary-card-element" + " fourth");
          this.$refs[idx + "footer"].innerHTML === card.firstFooter
            ? (this.$refs[idx + "footer"].innerHTML = card.fourthFooter)
            : (this.$refs[idx + "footer"].innerHTML = card.firstFooter);
          this.$refs[idx + "h2"].innerHTML == card.firstP
            ? (this.$refs[idx + "h2"].innerHTML = card.fourthP)
            : (this.$refs[idx + "h2"].innerHTML = card.firstP);
          this.$refs[idx + "span"].innerHTML == card.firstSpan
            ? (this.$refs[idx + "span"].innerHTML = card.fourthSpan)
            : (this.$refs[idx + "span"].innerHTML = card.firstSpan);
          this.$refs[idx + 1].className = "summary-card-element" + " second";
          this.$refs[idx + 2].className = "summary-card-element" + " third";
          this.$refs[idx + "p"].innerHTML == card.arrowFirst
            ? (this.$refs[idx + "p"].innerHTML = card.arrowFourth)
            : (this.$refs[idx + "p"].innerHTML = card.arrowFirst);
          this.setArrow(idx + "p", card)
            ? (this.$refs[idx + "arr"].src = this.getImgUrl("upArrow"))
            : (this.$refs[idx + "arr"].src = this.getImgUrl("downArrow"));
        }
      }
    },
    checkHandler(idx, card) {
      if (card.fourth) {
        this.$refs[idx + "3"].className.includes("hidden")
          ? (this.$refs[idx + "3"].className =
              "summary-card-element" + " fourth")
          : (this.$refs[idx + "3"].className = "hidden");
        this.resetSummaryCard(idx, card);
      }
    },
  },
};
</script>

<style src="./SummaryAnalitics.css" scoped>
</style>

