<template>
  <div class="calender">
    <table>
      <caption>
        <select v-model.number="year">
          <option v-for="i of 490" :key="i">{{ i + 1969 }}</option>
        </select>
        <select v-model.number="month">
          <option v-for="i of 12" :key="i">{{ i }}</option>
        </select>
      </caption>
      <thead>
        <tr>
          <th>воскресенье</th>
          <th>понедельник</th>
          <th>вторник</th>
          <th>среда</th>
          <th>четверг</th>
          <th>пятница</th>
          <th>суббота</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="(a, index) of calender.length / 7" :key="index">
          <td
            v-for="i of 7"
            :key="i"
            :class="{ cur: calender[index * 7 + (i - 1)].cur }"
          >
            {{ calender[index * 7 + (i - 1)].fullDay }}
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script>
export default {
  data() {
    return {
      year: 2018,
      month: 1,
    };
  },
  computed: {
    calender() {
      var arr = [];

      // новые данные имеют три параметра: 1, год 2. месяц 3. По умолчанию 1 Если это 0, это означает последний день предыдущего месяца - первые два дня 3 послезавтра
      var nowMonthLength = new Date(this.year, this.month, 0).getDate();
      var nowMonthFirstWeek = new Date(this.year, this.month - 1).getDay();
      var lastMonthLength = new Date(this.year, this.month - 1, 0).getDate();
      console.log("В этом месяце есть:" + nowMonthLength);
      console.log("Первый день месяца" + nowMonthFirstWeek);
      console.log("В прошлом месяце" + lastMonthLength);

      // this.month = parseInt(this.month);
      // Какой месяц предыдущий месяц каждого месяца
      var pmonth = this.month == 1 ? 12 : this.month - 1;
      // в прошлом году
      var pyear = this.month == 1 ? this.year - 1 : this.year;
      // в следующем месяце
      var nmonth = this.month == 12 ? 1 : this.month + 1;
      // в следующем месяце
      var nyear = this.month == 12 ? this.year + 1 : this.year;
      // дополненная нулями функция
      // function toTwo(n) {
      //     return n < 10 ? '0' + n : n;
      // }
      function buling(n) {
        return n.toString().length > 1 ? n.toString() : "0" + n.toString();
      }
      // дополняем последние дни прошлого месяца
      while (nowMonthFirstWeek--) {
        arr.unshift({
          day: lastMonthLength,
          cur: true,
          fullDay: `${pyear}-${buling(pmonth)}-${buling(lastMonthLength)}`,
        });
        lastMonthLength--;
      }
      console.log(arr);

      // дни месяца
      var _a = 1;
      while (nowMonthLength--) {
        arr.push({
          day: _a,
          cur: false,
          fullDay: `${this.year}-${buling(this.month)}-${buling(_a)}`,
        });
        _a++;
      }

      // завершить в следующем месяце
      var nextLength = arr.length > 35 ? 42 - arr.length : 35 - arr.length;
      _a = 1;
      while (nextLength--) {
        arr.push({
          day: _a,
          cur: true,
          fullDay: `${nyear}-${buling(nmonth)}-${buling(_a)}`,
        });
        _a++;
      }
      return arr;
    },
  },
};
</script>

<style scoped src="./Cal.css">
</style>