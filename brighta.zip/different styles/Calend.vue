<template>
  <div id="calendar_wrapper">
    <table class="table">
      <thead>
        <tr>
          <td>
            <button @click="decrease"><div id="left_arrow"></div></button>
          </td>
          <td colspan="5">{{ monthes[month] }} {{ year }}</td>
          <td>
            <button @click="increase"><div id="right_arrow"></div></button>
          </td>
        </tr>
        <tr>
          <td v-for="d in day" :key="d" class="day">{{ d }}</td>
        </tr>
      </thead>
      <tbody>
        <tr v-for="week in calendar()" :key="week">
          <td
            v-for="(day, idx) in week"
            :key="idx"
            :style="{ color: day.weekend, 'background-color': day.current }"
          >
            {{ day.index }}
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script>
export default {
  data() {
    return {
      month: new Date().getMonth(),
      year: new Date().getFullYear(),
      day: ["Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"],
      monthes: [
        "Январь",
        "Февраль",
        "Март",
        "Апрель",
        "Май",
        "Июнь",
        "Июль",
        "Август",
        "Сентябрь",
        "Октябрь",
        "Ноябрь",
        "Декабрь",
      ],
      date: new Date(),
    };
  },
  methods: {
    calendar() {
      let days = [];
      let week = 0;
      days[week] = [];
      let dlast = new Date(this.year, this.month + 1, 0).getDate();
      for (let i = 1; i <= dlast; i++) {
        if (new Date(this.year, this.month, i).getDay() != 1) {
          let a = { index: i };
          days[week].push(a);
          if (
            i == new Date().getDate() &&
            this.year == new Date().getFullYear() &&
            this.month == new Date().getMonth()
          ) {
            a.current = "#747ae6";
          }
          if (
            new Date(this.year, this.month, i).getDay() == 6 ||
            new Date(this.year, this.month, i).getDay() == 0
          ) {
            a.weekend = "#ff0000";
          }
        } else {
          week++;

          days[week] = [];
          let a = { index: i };
          days[week].push(a);
          if (
            i == new Date().getDate() &&
            this.year == new Date().getFullYear() &&
            this.month == new Date().getMonth()
          ) {
            a.current = "#747ae6";
          }
          if (
            new Date(this.year, this.month, i).getDay() == 6 ||
            new Date(this.year, this.month, i).getDay() == 0
          ) {
            a.weekend = "#ff0000";
          }
        }
      }
      if (days[0].length > 0) {
        for (let i = days[0].length; i < 7; i++) {
          days[0].unshift("");
        }
      }
      return days;
    },
    decrease() {
      this.month--;
      if (this.month < 0) {
        this.month = 12;
        this.month--;
        this.year--;
      }
    },
    increase() {
      this.month++;
      if (this.month > 11) {
        this.month = -1;
        this.month++;
        this.year++;
      }
    },
  },
};
</script>

<style scoped src="./Calendar.css">
</style>