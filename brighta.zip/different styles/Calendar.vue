<template>
  <article id="calendar">
    <header>
      <div class="current-date">
        <div class="today">
          <div class="arrow_border" @click="monthDown()">
            <div class="arrow-left"></div>
          </div>
          <div>{{ month[currentDate.month] }}, {{ currentDate.year }}</div>
          <div class="arrow_border" @click="monthUp()">
            <div class="arrow-right"></div>
          </div>
        </div>
      </div>
    </header>
    <section id="wekdays-wrapper">
      <div class="weekdays">
        <div class="weekday" v-for="(weekday, index) in weekdays" :key="index">
          {{ weekday }}
        </div>
      </div>
      <div class="date">
        <div
          class="day-hidden"
          v-for="(n, index) in firstMonthDay - 1"
          :key="'prev' + index"
        >
          {{ prevMonthDays + 1 - firstMonthDay + n }}
        </div>
        <div
          class="day"
          :class="{ active: n === currentDate.date }"
          @click="currentDate.date = n"
          v-for="(n, index) in currentMonthDays"
          :key="'day' + index"
        >
          {{ n }}
        </div>
        <div
          class="day-hidden"
          v-for="(n, index) in 43 - (currentMonthDays + firstMonthDay)"
          :key="'next' + index"
        >
          {{ n }}
        </div>
      </div>
    </section>
    <section id="button-wrapper">
      <button>Отмена</button>
      <button>Обновить</button>
    </section>
  </article>
</template>

<script>
export default {
  data: function () {
    return {
      weekdays: ["Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"],
      //   weekdayNames: [
      //     "Sunday",
      //     "Monday",
      //     "Tuesday",
      //     "Wednesday",
      //     "Thursday",
      //     "Friday",
      //     "Saturday",
      //   ],
      month: [
        "Январь",
        "Февраль",
        "Март",
        "Апрель",
        "Май",
        "Июнь",
        "Июль",
        "Август",
        "Сентябрь",
        "Октябрь",
        "Ноябрь",
        "Декабрь",
      ],
      currentDate: {
        date: 0,
        month: 0,
        year: 0,
      },
    };
  },
  computed: {
    prevMonthDays() {
      let year =
        this.currentDate.month === 0
          ? this.currentDate.year - 1
          : this.currentDate.year;
      let month = this.currentDate.month === 0 ? 12 : this.currentDate.month;
      return new Date(year, month, 0).getDate();
    },
    firstMonthDay() {
      let firstDay = new Date(
        this.currentDate.year,
        this.currentDate.month,
        1
      ).getDay();
      if (firstDay === 0) firstDay = 7;
      return firstDay;
    },
    currentDay() {
      return new Date(
        this.currentDate.year,
        this.currentDate.month,
        this.currentDate.date
      ).getDay();
    },
    currentMonthDays() {
      return new Date(
        this.currentDate.year,
        this.currentDate.month + 1,
        0
      ).getDate();
    },
  },
  methods: {
    getCurrentDate() {
      let today = new Date();
      this.currentDate.date = today.getDate();
      this.currentDate.month = today.getMonth();
      this.currentDate.year = today.getFullYear();
    },
    dateUp() {
      if (this.currentDate.date === this.currentMonthDays) {
        this.currentDate.date = 1;
        this.monthUp();
      } else {
        this.currentDate.date += 1;
      }
    },
    dateDown() {
      if (this.currentDate.date === 1) {
        this.currentDate.date = this.prevMonthDays;
        this.monthDown();
      } else {
        this.currentDate.date -= 1;
      }
    },
    monthUp() {
      if (this.currentDate.month === 11) {
        this.currentDate.month = 0;
        this.currentDate.year += 1;
      } else {
        this.currentDate.month += 1;
      }
    },
    monthDown() {
      if (this.currentDate.month === 0) {
        this.currentDate.month = 11;
        this.currentDate.year -= 1;
      } else {
        this.currentDate.month -= 1;
      }
    },
  },
  created() {
    this.getCurrentDate();
  },
};
</script>

<style scoped src="./Calendar.css">
</style>