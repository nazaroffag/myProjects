# brighta

https://www.figma.com/file/0PmcyoSHSRx6sVHTT8mWMN/Analytics%3A-dashboard?node-id=0%3A1
нужно сверстать раздел Аналитика, страница Сводная и встроить на платформу

## Project setup

```
npm install
```

### Compiles and hot-reloads for development

```
npm run serve
```

### Compiles and minifies for production

```
npm run build
```

### Lints and fixes files

```
npm run lint
```

### Customize configuration

See [Configuration Reference](https://cli.vuejs.org/config/).
